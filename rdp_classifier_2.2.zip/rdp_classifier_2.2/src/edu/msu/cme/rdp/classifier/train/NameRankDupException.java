package edu.msu.cme.rdp.classifier.train;


public class NameRankDupException extends Exception {

    public NameRankDupException(String msg){
        super(msg);
    }
}
